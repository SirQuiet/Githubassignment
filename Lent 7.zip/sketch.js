var rainDrops = [];
var clouds = [];

function setup() {
  createCanvas(600, 600);
  // create 8 Clouds
  for (var i = 0; i < 8; i++) {
    clouds[i] = new Cloud();
  }
  fill(240);
  noStroke();
}
// This is a class of a RainDrop
class RainDrop {
  constructor(posX = random(width), posY = random(height)) {
    this.posX = posX;
    this.posY = posY;
  }
  // function to update the position of the rain drop
  update() {
    this.posY += 1;
    // delete rainDrop if past end of screen
    if (this.posY > height) {
      let index = rainDrops.indexOf(this);
      rainDrops.splice(index, 1);
    }
  }
  // function to display the rain drop with white color
  display() {
    stroke(255);
    strokeWeight(1);
    line(this.posX, this.posY - 5, this.posX, this.posY + 5);
  }
}

function draw() {
  background('skyblue');
  // create a random number of rainDrops each time draw is called
  for (let i = 0; i < random(5); i++) {
    let rainDrop = new RainDrop(random(width), random(height));
    rainDrops.push(rainDrop);
  }
  // move and display each cloud everytime
  for (var i = 0; i < clouds.length; i++) {
    clouds[i].move();
    clouds[i].display();
  }


  for (let drop of rainDrops) {
    drop.update(); // update rainDrop position
    drop.display(); // draw rainDrop
  }
  this.drawRainbow(); // draws the rainbow
}

// This draws a rainbow
function drawRainbow() {
  noFill();
  strokeWeight(5);
  let [violet, indigo, blue, green, yellow, orange, red] = [color(127, 0, 255), color(52, 39, 89), color(0, 0, 255),
    color(0, 255, 0), color(255, 255, 0), color(255, 165, 0), color(255, 0, 0)
  ];
 let colors = [red, orange, yellow, green, blue, indigo, violet];
  // (w,h) varies from (320,320) to (250,250)
  let w = 350;
  let h = 350;
  // draw each color arc with alpha set to 50 this will produce a lighter version of that color
  for (let i = 0; i <= 6; i++) {
    let color = colors[i];
    color.setAlpha(50);
    stroke(color);
    arc(width - 200, 200, w, h, -PI / 2 - .7, -.2);
    w = w - 10;
    h = h - 10;

  }
}


function Cloud() {
  this.x = random(0, width);
  this.y = random(0, 100);

  // display the cloud
  this.display = function() {
    stroke(255);
    strokeWeight(1);
    fill(255);
    ellipse(this.x, this.y, 24, 24);
    ellipse(this.x + 10, this.y + 10, 24, 24);
    ellipse(this.x + 30, this.y + 10, 24, 24);
    ellipse(this.x + 30, this.y - 10, 24, 24);
    ellipse(this.x + 20, this.y - 10, 24, 24);
    ellipse(this.x + 40, this.y, 24, 24);
  }

  // move the cloud
  this.move = function() {
    this.x = this.x += 1;
    this.y = this.y + random(-1, 1);

    if (this.x >= width) {
      this.x = 0;
    }
  }
}