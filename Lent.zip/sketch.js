// Yes. I put way too much effort into this.
// I sincerely apologize.


var fr = 30; // starting FPS
var change = false; // variable that assists in affecting FPS
var press = 1; // Starting color is red
var fillR = 0;
var fillG = 0;
var fillB = 0;

function setup() {

 createCanvas(510, 510);
  frameRate(fr);
}
 

function draw() {
  colorMode(RGB, 255, 255, 255);
  background(0);
  
  let centerX = height / 2;
  let centerY = width / 2;
  let x ="x - " + mouseX;
  let y ="y - " + mouseY;
  
  let d = int(dist(centerX, centerY, mouseX, mouseY));
  let ellipsesize = d / 5; 
  /* changes the size based on how far away the center of
     the colored ellipse is from the center of the canvas */
  
  strokeWeight(5);
  stroke(255);
  line(0, centerY, 510, centerY);
  // center dividing line
 
  
  strokeWeight(2);
  stroke(100);
  line(centerX, centerY, mouseX, mouseY);
  strokeWeight(5);
  stroke(255);
  line(mouseX, mouseY, pmouseX, pmouseY);
  // distance line (first), streak line (second)

  strokeWeight(2);
  stroke(255);
  if(press == 1 && mouseY >= centerY){
    fillR = 125;
    fillG = 0;
    fillB = 0;
  fill(fillR, fillG, fillB);
  ellipse(mouseX, mouseY, ellipsesize, ellipsesize);
    push();
    strokeWeight(3);
    textSize(14);
    text("Current color - Dark Red", 320, 40);
    pop();
  }
  else if(press == 2 && mouseY >= centerY){
    fillR = 0;
    fillG = 125;
    fillB = 0;
  fill(fillR, fillG, fillB);
  ellipse(mouseX, mouseY, ellipsesize, ellipsesize);
    push();
    strokeWeight(3);
    textSize(14);
    text("Current color - Dark Green", 320, 40);
    pop();
  }
  else if(press == 3 && mouseY >= centerY){
    fillR = 0;
    fillG = 0;
    fillB = 125;
  fill(fillR, fillG, fillB);
  ellipse(mouseX, mouseY, ellipsesize, ellipsesize);
    push();
    strokeWeight(3);
    textSize(14);
    text("Current color - Dark Blue", 320, 40);
    pop();
  }
  else if(press == 1){
    fillR = 255;
    fillG = 0;
    fillB = 0;
  fill(fillR, fillG, fillB);
  ellipse(mouseX, mouseY, ellipsesize, ellipsesize);
    push();
    strokeWeight(3);
    textSize(14);
    text("Current color - Red", 320, 40);
    pop();
  }
  else if(press == 2){
    fillR = 0;
    fillG = 255;
    fillB = 0;
  fill(fillR, fillG, fillB);
  ellipse(mouseX, mouseY, ellipsesize, ellipsesize);
    push();
    strokeWeight(3);
    textSize(14);
    text("Current color - Green", 320, 40);
    pop();
  }
  else if(press == 3){
    fillR = 0;
    fillG = 0;
    fillB = 255;
  fill(fillR, fillG, fillB);
  ellipse(mouseX, mouseY, ellipsesize, ellipsesize);
    push();
    strokeWeight(3);
    textSize(14);
    text("Current color - Blue", 320, 40);
    pop();
  } //handling the fill color of the ellipse & current color text
  
  fill(0);
  ellipse(centerX, centerY, 10, 10);
  ellipse(centerX, centerY, 1,1);
  ellipse(mouseX, mouseY, 1,1);
  // adds in the center circle, as well as the dot in the middle of it and the colored ellipse
  
  push();
  textSize(15);
  stroke(255);
  fill(0);
  
  push();
  translate((centerX + mouseX) / 2, (centerY + mouseY) / 2);
  text(d, -10, -5);
  pop(); // shows current distance between the center and the middle of the colored ellipse
  
  text("Enter = change circle color", 320, 20);
  text("Colors turn dark down here.", 165, 500);
  // static, unchanging text
  
  if(change == false){
     text("Click to change framerate to 10", 10, 20);
     fr = 30;
     frameRate(fr);
     }
  else if(change == true){
     text("Click to change framerate to 30", 10, 20);
      fr = 10;
      frameRate(fr);
     }

  
  
  if(mouseX >= 460 && mouseY <= 40){
    text(x, mouseX - 50, mouseY + 20);
    text(y, mouseX - 50, mouseY + 40);
  }
  else if (mouseX <= 50 && mouseY <= 40){
    text(x, mouseX + 5, mouseY + 20);
    text(y, mouseX + 5, mouseY + 40);
  }
  else if (mouseX <= 50){
    text(x, mouseX + 5, mouseY - 30);
    text(y, mouseX + 5, mouseY - 10);
  }
  else if(mouseX >= 460){
    text(x, mouseX - 50, mouseY - 30);
    text(y, mouseX - 50, mouseY - 10);
  }
  else if(mouseY <= 20){
    text(x, mouseX - 50, mouseY + 20);
    text(y, mouseX + 5, mouseY + 20);
  }
  else{
     text(x, mouseX - 50, mouseY - 10);
     text(y, mouseX + 5, mouseY - 10);
  }
  pop();
  /* This entire segment displays the x and y coordinate of the ellipse,
     as well as make sure the text stays visible on the canvas by readjusting */
  
  
}
function mousePressed(){
  if(change == false){
     change = true;
     }
  else if(change == true){
     change = false;
     }
} // affects what the current framerate is when the mouse is clicked

function keyPressed() {
  if (keyCode == ENTER && press == 1) {
  press = 2;
  } 
  else if(press == 2){
   press = 3;
  }
  else if(press == 3){
   press = 1;
  }
} // affects which color is active when enter is pressed
 