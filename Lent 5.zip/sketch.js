var screenX, screenY;
var b1X, b1Y; // Left rectangle button
var b2X, b2Y; // Right rectangle button
var bpowX, bpowY; // Circular power button
var screenSize = 220;
var b1Size = 20;
var b2Size = 20;
var bpowSize = 25;
var b1Color, b2Color, bpowColor;
var b1HL, b2HL, bpowHL; // HL - highlight
var b1Hover = false;
var b2Hover = false;
var bpowHover = false;
var tvPower = false; 
var channel1 = false;
var channel2 = false;
var c1Color, c2Color;
var x = 80;    // x thru x3 & speed1 thru speed3 for channel1 content
var x2 = 120;
var x3 = 160;
var speed = 2;
var speed2 = 3;
var speed3 = 4;
var y = 140;    // y thru y3 & speed4 thru speed6 for channel 2 content
var y2 = 220;
var y3 = 270;
var speed4 = 2;
var speed5 = 3;
var speed6 = 4;
function setup() {
  createCanvas(400, 400);
  
  screenX = 65;
  screenY = 125;
  b1X = 130;
  b1Y = 320;
  b2X = 170;
  b2Y = 320;
  bpowX = 85;
  bpowY = 330;
  
  b1Color = color(75);
  b2Color = b1Color;
  bpowColor = color(200,0,0);
  b1HL = color(100);
  b2HL = b1HL;
  bpowHL = color(225,25,25);
  c1Color = color(50,219,163);
  c2Color = color(153,51,0);
  
}

function draw() {
  background(220);
  update(mouseX, mouseY);
  
  strokeWeight(2); // draws in the general TV shape
  stroke(0);
  line(0,350, 400,350);
  fill(150);
  rect(50,100, 300,250, 5);
  fill(0);
  line(300,100,300,350);
  line(180,100,160,50);
  line(160,50,140,30);
  line(220,100,260,50);
  line(260,50,280,60);

  if (tvPower) {
    fill(255);
  }
  else {
    fill(0);
  }
  if(tvPower && channel1 == 1){
    fill (c1Color);
  }
  if(tvPower && channel2 == 1){
    fill (c2Color);
  }
  rect(screenX,screenY, screenSize,screenSize - 40, 20);
  
   if (bpowHover) {
    fill(bpowHL);
  } else {
    fill(bpowColor);
  }
  ellipse(bpowX,bpowY, bpowSize);
  
   if (b1Hover) {
    fill(b1HL);
  } else {
    fill(b1Color);
  }
  rect(b1X,b1Y, b1Size,b1Size);
   if (b2Hover) {
    fill(b2HL);
  } else {
    fill(b2Color);
  }
  rect(b2X,b2Y, b2Size,b2Size);
  
  if(channel1 == 1 && channel2 != 1 && tvPower == 1){ //draws the content in each channel
    stroke(74, 44, 242);
    strokeWeight(5);
    noFill();
    ellipse(x,160, 15,15);
    ellipse(x2,220, 15,15);
    ellipse(x3,270, 15,15);
    if(x > 275){
      speed = -2;
    }
    else if (x  < 75){
      speed = 2;
    }
    if(x2 > 275){
      speed2 = -3;
    }
    else if (x2  < 75){
      speed2 = 3;
    }
    if(x3 > 275){
      speed3 = -4;
    }
    else if (x3  < 75){
      speed3 = 4;
    }
    x = x + speed;
    x2 = x2 + speed2;
    x3 = x3 + speed3;
  }
  else if(channel2 == 1 && channel1 != 1 && tvPower == 1){
    stroke(242, 236, 44);
    strokeWeight(10);
    fill(232, 54, 32);
    ellipse(100,y, 20,20);
    ellipse(170,y2, 20,20);
    ellipse(240,y3, 20,20);
    if(y > 287){
      speed4 = -2;
    }
    else if (y < 143){
      speed4 = 2;
    }
    if(y2 > 287){
      speed5 = -3;
    }
    else if (y2 < 143){
      speed5 = 3;
    }
    if(y3 > 287){
      speed6 = -4;
    }
    else if (y3 < 143){
      speed6 = 4;
    }
    
    y = y + speed4;
    y2 = y2 + speed5;
    y3 = y3 + speed6;
  }
  
}

function update( x,  y) {
  if ( bpowHoverf(bpowX,bpowY, bpowSize) ) {
    bpowHover = true;
    b1Hover = false;
    b2Hover = false;
  } else if ( b1Hoverf(b1X,b1Y, b1Size,b1Size) ) {
    b1Hover = true;
    b2Hover = false;
    bpowHover = false;
  }else if ( b2Hoverf(b2X,b2Y, b2Size,b2Size) ) {
    b2Hover = true;
    b1Hover = false;
    bpowHover = false;
  } else {
    bpowHover = b1Hover = b2Hover = false;
  }
}

function mousePressed() {
  if (bpowHover && tvPower == 0) { // Turns tv on if it's off & vice versa
    tvPower = true;
    channel1 = false;
    channel2 = false;
  }
  else if (bpowHover && tvPower == 1){
    tvPower = false;
  }
  if (b1Hover && tvPower == 1) { // switches to channel 1 with mouse
    channel1 = true;
    channel2 = false;
  }

}

function keyPressed(){ 
  if (b2Hover && tvPower == 1 && keyCode == ENTER) {
    channel2 = true;
    channel1 = false;
  } // switches to channel 2 when pressing enter over the second button.
}

function b1Hoverf( x,  y,  width,  height)  {
  if (mouseX >= x && mouseX <= x+width && 
      mouseY >= y && mouseY <= y+height) {
    return true;
  } else {
    return false;
  }
}

function b2Hoverf( x,  y,  width,  height)  {
  if (mouseX >= x && mouseX <= x+width && 
      mouseY >= y && mouseY <= y+height) {
    return true;
  } else {
    return false;
  }
}

function bpowHoverf( x,  y,  diameter) {
  var disX = x - mouseX;
  var disY = y - mouseY;
  if (sqrt(sq(disX) + sq(disY)) < diameter/2 ) {
    return true;
  } else {
    return false;
  }
}